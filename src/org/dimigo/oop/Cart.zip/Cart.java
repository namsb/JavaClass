package org.dimigo.oop;
import java.util.*;

/**
 * 
 */
public class Cart {

    private String Object;
    private int price;
    private int num;
    private boolean stock;
    private float evaluate;

    public int payment(int card) {
        // TODO implement here
        return 0;
    }
    public void cartIn(int num) {
        // TODO implement here
    }
    public void cartOut(int num) {
        // TODO implement here
    }
    public boolean logIn(String id, String pw) {
        // TODO implement here
        return false;
    }
    public void logOut() {
        // TODO implement here
    }

}